import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:hikeguide/firebase_options.dart';
import 'package:hikeguide/services/user_model.dart';
import 'package:hikeguide/services/auth_local_storage.dart';
import 'package:hikeguide/core/presentation/screens/home/home_screen.dart';

Future<Widget> bootstrap() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  await Hive.initFlutter();
  Hive.registerAdapter(UserModelAdapter());

  final AuthLocalStorage localStorage = AuthLocalStorage();
  final UserModel? localUser = await localStorage.loadUser();

  if (localUser != null) {
    print('🟢 Local user found: ${localUser.username ?? "Anonymous"}');
  } else {
    print('🔴 No local user found.');
  }

  return MaterialApp(
    title: 'HikeGuide',
    debugShowCheckedModeBanner: false,
    theme: ThemeData.light(), // ή custom buildTheme()
    darkTheme: ThemeData.dark(),
    home: const HomeScreen(),
  );
}
