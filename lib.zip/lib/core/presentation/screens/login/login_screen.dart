import 'package:flutter/material.dart';
import 'widgets/login_form.dart';
import 'widgets/login_header.dart';
import 'widgets/social_login_buttons.dart';
import 'widgets/login_footer.dart'; // ✅ νέο import

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: const [
            LoginHeader(),
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.symmetric(horizontal: 24),
                child: Column(
                  children: [
                    LoginForm(),
                    SizedBox(height: 32),
                    SocialLoginButtons(),
                    SizedBox(height: 32),
                    LoginFooter(), // ✅ footer μετά τα social
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
